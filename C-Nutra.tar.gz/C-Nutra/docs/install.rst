Install
=========

This is where you write how to get a new laptop to run this project.
